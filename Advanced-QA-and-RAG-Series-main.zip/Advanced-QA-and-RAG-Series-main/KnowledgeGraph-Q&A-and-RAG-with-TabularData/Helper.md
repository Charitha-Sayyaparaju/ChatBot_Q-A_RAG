1. Presentation
Prepare the environment
2. Readme: Create GraphDB
3. Readme: prepare the GraphDB
4. Test DB connection
5. Test OpenAI models
6. Go through the notebooks (mention open ai folder)
    - prepare the csv file
    - prepare the grpah and inject data: construct the knowlege graph
    - prepare the vector index and inject data
    - query the graph
    - Q&A with the graph agent
    - RAG with the Graph vector index
7. Chatbot test and evaluation
8. Microsoft project
    - presentation
    - code review